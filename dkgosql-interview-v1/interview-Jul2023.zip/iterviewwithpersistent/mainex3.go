package main

func main() {
	select {}
}
