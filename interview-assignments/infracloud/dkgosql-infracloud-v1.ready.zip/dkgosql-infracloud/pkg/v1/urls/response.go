package urls

type URLReponse struct {
	ShortURL string `json:"shortURL"`
}
