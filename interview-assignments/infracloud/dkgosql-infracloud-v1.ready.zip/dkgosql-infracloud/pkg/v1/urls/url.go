package urls

import (
	"fmt"
	"log"

	"dkgosql.com/url-shortener-service/internals/consts"
	"github.com/gin-gonic/gin"
	"github.com/spf13/viper"
	"github.com/zpnk/go-bitly"
)

func GetURLShortner(c *gin.Context) (URLReponse, error) {
	out := URLReponse{}
	inputRequest := URLRequest{}
	err := c.BindJSON(&inputRequest)
	if err != nil {
		errmsg := fmt.Errorf("error found in input request: %v", err)
		log.Printf("%s", errmsg)
		return out, errmsg
	}

	log.Println("inputRequest:", inputRequest)
	outURL, err := GetShortURL(inputRequest.URL)

	if err != nil {
		log.Printf("Error found in GetShortURL: %s", err)
		return out, err
	}

	out.ShortURL = outURL
	return out, nil
}

func GetShortURL(URL string) (string, error) {
	if len(URL) == 0 {
		log.Printf("%s", consts.URL_EMPTY_ERROR)
		return "", fmt.Errorf("%s", consts.URL_EMPTY_ERROR)
	}

	bitlyToken := viper.GetString("BITLY_ACCESS_TOKEN")
	b := bitly.New(bitlyToken)
	shortURL, err := b.Links.Shorten(URL)

	if err != nil {
		log.Printf("Error found in bitly shorten URL: %s", err)
		return "", err
	}

	return shortURL.URL, nil
}
