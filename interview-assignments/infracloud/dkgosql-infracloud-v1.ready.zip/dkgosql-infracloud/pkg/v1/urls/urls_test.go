package urls_test

import (
	"bytes"
	"encoding/json"
	"log"
	"net/http"
	"net/http/httptest"
	"os"
	"testing"

	"dkgosql.com/url-shortener-service/internals/handlers"
	"dkgosql.com/url-shortener-service/pkg/v1/urls"
	"github.com/gin-gonic/gin"
	"github.com/magiconair/properties/assert"
	"github.com/spf13/viper"
)

func TestShortURL_Success(t *testing.T) {
	r := SetUpRouter()

	inputRequest := urls.URLRequest{URL: "https://news.google.com/topstories?tab=mn&hl=en-IN&gl=IN&ceid=IN:en"}
	jsonValue, _ := json.Marshal(inputRequest)
	req, _ := http.NewRequest("POST", "/shorturl", bytes.NewBuffer(jsonValue))

	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)
	assert.Equal(t, http.StatusOK, w.Code)
}

func TestShortURL_Empty_Body_Failed(t *testing.T) {
	r := SetUpRouter()

	inputRequest := urls.URLRequest{}
	jsonValue, _ := json.Marshal(inputRequest)
	req, _ := http.NewRequest("POST", "/shorturl", bytes.NewBuffer(jsonValue))

	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)
	assert.Equal(t, http.StatusBadRequest, w.Code)
}

func TestShortURL_Empty_URL_Failed(t *testing.T) {
	r := SetUpRouter()

	inputRequest := urls.URLRequest{URL: ""}
	jsonValue, _ := json.Marshal(inputRequest)
	req, _ := http.NewRequest("POST", "/shorturl", bytes.NewBuffer(jsonValue))

	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)
	assert.Equal(t, http.StatusBadRequest, w.Code)
}

func TestShortURL_Missing_Body_Failed(t *testing.T) {
	r := SetUpRouter()

	req, _ := http.NewRequest("POST", "/shorturl", nil)

	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)
	assert.Equal(t, http.StatusBadRequest, w.Code)
}

func SetUpRouter() *gin.Engine {
	viper.SetConfigName("config-local")
	log.Println("Current Config :", os.Getenv("MICROSERVICECDEMONEWAPI"))

	viper.AddConfigPath("../../../cmd/")
	viper.AutomaticEnv()

	viper.SetConfigType("yml")

	if err := viper.ReadInConfig(); err != nil {
		log.Fatalf("Error reading config file, %s", err)
	}

	router := gin.Default()
	shortnerHandler := handlers.NewURLShortnerHandler()
	router.POST("/shorturl", shortnerHandler.Shorturl)
	return router
}
