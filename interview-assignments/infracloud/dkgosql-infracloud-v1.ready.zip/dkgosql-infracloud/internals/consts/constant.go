package consts

const (
	URL_EMPTY_ERROR = "URL is empty"
)
