package handlers

import (
	"github.com/gin-gonic/gin"
)

func SetupRouter() *gin.Engine {
	r := gin.Default()
	r.Use()
	healthHandler := NewHealthHandler()
	shortnerHandler := NewURLShortnerHandler()
	r.GET("/health", healthHandler.Health)
	r.POST("/shorturl", shortnerHandler.Shorturl)

	return r
}
