package handlers

import (
	"fmt"
	"net/http"

	"dkgosql.com/url-shortener-service/pkg/v1/urls"
	"github.com/gin-gonic/gin"
)

type URLShortnerHandler interface {
	Shorturl(c *gin.Context)
}

type shortnerHandler struct {
}

func NewURLShortnerHandler() URLShortnerHandler {
	return shortnerHandler{}
}

func (urlSt shortnerHandler) Shorturl(c *gin.Context) {
	out, err := urls.GetURLShortner(c)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"action": "shortner", "status": "error", "message": fmt.Sprintf("Error found: %s", err)})
		return
	}
	c.JSON(http.StatusOK, gin.H{"action": "shortner", "status": "success", "data": out})
}
