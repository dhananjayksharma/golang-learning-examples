package main

import (
	"bytes"
	_ "embed"
	"fmt"
	"strings"
	"sync"
	"time"
)

var (
	//go:embed data/prefixes.txt
	data []byte
)

func main() {
	start := time.Now()
	var wg sync.WaitGroup
	var prefixesMatchedList []string
	var resultPrefixesMatched []string
	var prefixesMaxLength int = 0
	fmt.Println("True caller start")

	prefixes := bytes.Split(data, []byte{'\n'})
	prefixesLength := len(prefixes)
	fmt.Println("prefixesLength : ", prefixesLength)

	workerMax := 10
	// Find Remainder
	remainder := prefixesLength % workerMax
	fmt.Println("remainder: ", remainder)
	pages := prefixesLength / workerMax
	inputStr := "op" //"xyiuoXX" //xyi
	skip, take := 0, pages
	if workerMax == 1 || (workerMax > 0 && pages == 0) {
		// fmt.Println("All data skip %v, take %v", skip, take)
		wg.Add(1)
		go fetchMatchedPrefix(&wg, 1, inputStr, &prefixes, &prefixesMatchedList, &prefixesMaxLength)

	} else if pages >= workerMax {
		for counter := 0; counter < workerMax; counter++ {
			wg.Add(1)
			data_list := prefixes[skip:take]
			// log.Printf("Full Page skip %v, take %v \n", skip, take)
			skip = skip + pages
			take = take + pages
			go fetchMatchedPrefix(&wg, counter, inputStr, &data_list, &prefixesMatchedList, &prefixesMaxLength)
		}

		if remainder > 0 {
			wg.Add(1)
			skip = pages * workerMax
			take = pages*workerMax + remainder
			data_list := prefixes[skip:take]
			// log.Printf("Full Page skip %v, take %v \n", skip, take)
			go fetchMatchedPrefix(&wg, workerMax, inputStr, &data_list, &prefixesMatchedList, &prefixesMaxLength)
		}
	} else {
		fmt.Printf("Number of worker and pages does not matches: worker %v, pages %v\n", workerMax, pages)
	}

	// Code to measure
	duration := time.Since(start)

	wg.Wait()
	fmt.Println("Max Length: ", prefixesMaxLength)
	fmt.Println(duration)
	// fmt.Println("All Prefixes List: ", prefixesMatchedList)

	findLongestMatches(&resultPrefixesMatched, &prefixesMatchedList, &prefixesMaxLength)
	fmt.Println("Final Prefixes List: ", resultPrefixesMatched)
}

func fetchMatchedPrefix(wg *sync.WaitGroup, counter int, searchStr string, prefixes *[][]byte, prefixesMatchedList *[]string, prefixesMaxLength *int) {
	// fmt.Println("Counter:", counter)
	for _, prefix := range *prefixes {
		// fmt.Println("all: ",string(prefix))
		prefixString := string(prefix)
		// fmt.Println("prefix:", string(prefix))
		if strings.HasPrefix(prefixString, searchStr) && len(prefixString) > 0 {
			*prefixesMatchedList = append(*prefixesMatchedList, prefixString)
			prefixLength := len(prefixString)
			if prefixLength > *prefixesMaxLength {
				*prefixesMaxLength = prefixLength
			}
		}
	}
	wg.Done()
}

func findLongestMatches(resultPrefixesMatched *[]string, prefixesMatchedList *[]string, prefixesMaxLength *int) {
	for _, prefix := range *prefixesMatchedList {
		if len(prefix) == *prefixesMaxLength {
			*resultPrefixesMatched = append(*resultPrefixesMatched, prefix)
		}
	}
}
