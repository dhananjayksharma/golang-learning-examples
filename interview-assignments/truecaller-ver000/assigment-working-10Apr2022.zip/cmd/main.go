package main

import (
	"fmt"
	"log"

	"dkgosql.com/match-prefix-service/internal/matchprefixes"
)

func main() { 
	fmt.Println("True caller start")
	inputStr := "xyi" //"xyiuoXX" //xyi
	resultPrefixesMatched, err := matchprefixes.FindPrefix(inputStr)
	if err != nil {
		log.Printf("Error found while calling matchprefixes.FindPrefix(inputStr) Err: %v", err)
	} else{
		fmt.Println("Final Prefixes List: ", resultPrefixesMatched)
	}
 
}
