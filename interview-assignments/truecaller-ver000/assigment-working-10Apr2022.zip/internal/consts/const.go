package consts

const (
	ERROR_DATA_NOT_FOUND = "Prefix data not found error"
	ERROR_EMPTY_DATA = "Empty data file error"
 
	WORKER = 3
)