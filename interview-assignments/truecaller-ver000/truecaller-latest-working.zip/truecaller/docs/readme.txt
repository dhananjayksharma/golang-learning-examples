go mod init dkgosql.com/match-prefix-service && go mod tidy

